from flask import Flask, render_template, redirect, session, flash, request
app = Flask(__name__)
app.secret_key = "churros"
from mysqlconnection import MySQLConnector
mysql = MySQLConnector(app, 'wall')
import md5
import re
from datetime import datetime

app = Flask(__name__)
app.secret_key = "'secretKey"

from mysqlconnection import MySQLConnector
mysql = MySQLConnector(app, 'wall')
import md5
import re

email_regex = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

#login and registration complete/can post messages/couldn't get comments to post
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect('/wall')

    return render_template("index.html")

#lOGIN VALIDATION
@app.route('/login', methods=["POST"])
def login():
    if len(request.form['email']) < 1 or len(request.form['password']) < 1: # if either loing field blank redirect
        flash("You must enter both email and password.")
        return redirect("/")
    else:
        query = "SELECT * from users WHERE email = :email"
        data = {
            'email': request.form['email']
        }
        user = mysql.query_db(query, data)
        print user

        if user:
            if user[0]['password'] == md5.new(request.form['password']).hexdigest():
                session['user_id'] = user[0]['id']
                return redirect("/wall")
            else:
                flash("Your password is invalid.")
                return redirect("/")
        else:
            flash("Your email is not valid.")
            return redirect("/")


#LOGOUT
@app.route('/reset', methods=['POST'])
def log_out():
    return render_template("index.html")

#REGISTRATION VALIDATION

@app.route('/register', methods=["POST"])
def register_user():

    flag = True # will remain True, if no errors were detected

    # Not blank
    if len(request.form['first_name']) < 1:
        flag = False
        flash("Your entry for first name must not be blank.")
    if len(request.form['last_name']) < 1:
        flag = False
        flash("Your entry for last name must not be blank.")
    # Longer than 2 char
    if len(request.form['first_name']) < 3:
        flag = False
        flash("Your entry for first name must ne longer than 2 characters.")
    if len(request.form['last_name']) < 3:
        flag = False
        flash("Your entry for last name must be longer than 2 characters.")
    # all letters
    if not request.form["first_name"].isalpha() and not request.form["last_name"].isalpha():
        flag = False
        flash("Your first name and last name must be letters only")
    # email is valid
    if not email_regex.match(request.form['email']):
        flag = False
        flash("Your email is not valid.")
    # len password > 8
    if len(request.form['password']) < 8:
        flag = False
        flash("Your password must be 8 characters long.")
    # passwords match
    if request.form['password'] != request.form['c_password']:
        flag = False
        flash("Your passwords don't match.")

    if flag:
        print "User info is good."
        query = "INSERT into users (first_name, last_name, email, password, created_at, updated_at) VALUES (:first_name, :last_name, :email, :password, NOW(), NOW())"

        data = {
            'first_name': request.form['first_name'],
            'last_name': request.form['last_name'],
            'email': request.form['email'],
            'password': md5.new(request.form['password']).hexdigest()
        }

        session['user_id'] = mysql.query_db(query, data) # store in session logged in users id
        return redirect("/success")

    else:
        print "User info had errors."
        return redirect("/")



#DISPLAY MESSAGES AND COMMENTS
@app.route("/wall")
def dashboard():
    try:
        query = "SELECT * from users WHERE id=:user_id"
        data = {
            'user_id': session['user_id']
        }
        logged_in_user = mysql.query_db(query, data)

        # get messages

        messages = mysql.query_db("SELECT users.id AS users_id, users.first_name, users.last_name, messages.id AS message_id, messages.message, DATE_FORMAT(messages.created_at, '%M %e, %Y at %h:%i %p') as message_creation_date FROM users JOIN messages ON users.id = messages.user_id ORDER BY message_id DESC")
        comments = mysql.query_db("SELECT users.id AS user_id, users.first_name, users.last_name, comments.id AS comment_id, comments.comment, DATE_FORMAT(comments.created_at, '%M %e, %Y at %h:%i %p') as comment_creation_date, comments.message_id FROM users JOIN comments ON users.id = comments.user_id ORDER BY comment_id ASC")
        # render the wall
        return render_template("wall.html", logged_in_user = logged_in_user, messages=messages,comments=comments)
    except:
        return redirect("/")

#POST MESSAGE
@app.route('/message', methods=['POST']) #post a message and insert message intotable in datbase
def add_message():
    message= request.form['message']
    query = "INSERT INTO messages (message, created_at, updated_at, user_id) VALUES (:message, Now(), Now(), :user_id)"
    data = {
        'message': message,
        'user_id': session['user_id']
    }
    mysql.query_db(query, data)
    return redirect('/wall')

#DELETE MESSAGE
@app.route('/deletemessage', methods=['POST'])
def deletemessage():
    message_id = request.form['message_id'] #hidden input of message form
    print message_id
    query = "DELETE FROM messages WHERE id = :id"
    data = {'id':message_id}

    mysql.query_db(query, data)

    return redirect('/wall')

#DELETE COMMENT
@app.route('/deletecomment', methods=['POST'])
def deletecomment():
    comment_id = request.form['comment']
    query = "DELETE FROM comments WHERE id = :id"
    data = {'id':comment_id}
    mysql.query_db(query, data)
    return redirect('/wall')

#POST COMMENT
@app.route('/comment/<message_id>', methods=['POST'])
def comment(message_id):
    comment = request.form['postcomment']
    query = "INSERT INTO comments (comment, created_at, updated_at, message_id, user_id) VALUES (:comment, NOW(), NOW(), :message_id, :user_id)"
    data = {
        'comment': comment,
        'message_id': message_id,
        'user_id': session['user_id']
    }
    mysql.query_db(query, data)
    return redirect('/wall')



@app.route("/success")
def success():
    try:
        query = "SELECT * from users WHERE id=:user_id"
        data = {
            'user_id': session['user_id']
        }

        logged_in_user = mysql.query_db(query, data)

        print logged_in_user
        return render_template("success.html", logged_in_user = logged_in_user)
    except:
        return redirect("/")


app.run(debug=True)
