# -*- coding: utf-8 -*-
#from __future__ import unicode_literals
from django.db import models
from django.contrib import messages
import os, binascii
import re
import md5
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
ALPHA_REGEX = re.compile(r'^[A-Za-z]+$')


class UserManager(models.Manager):
    def register(self, postData):
        flag=True
        error=[]
        #first name cannot be blank
        if len(postData['first_name']) < 1:
            error.append('First Name Cannot Be Blank')

        #first name can only have letters
        elif not ALPHA_REGEX.match(postData['first_name']):
            error.append('First Name Cannot Contan Numbers')

        # last name cannot be blank
        if len(postData['last_name']) < 1:
            error.append('Last Name Must Not Be Blank')

        #last name can only have letters
        elif not ALPHA_REGEX.match(postData['last_name']):
            error.append('Last Name Cannot Contain Numbers')

        # Check whether email exists in db
        if User.objects.filter(email=postData['email']):
            error.append('Email Is Already Registered')

        #email cannot be blank
        if len(postData['email']) < 1:
            error.append("Email Cannot Be Blank")
            flag=False

        #check for proper email format
        elif not EMAIL_REGEX.match(postData['email']):
            error.append('Invalid Email Format')
            flag=False

        #password cannot be blank
        if len(postData['password']) < 1:
            error.append("Password Cannot Be Blank")
            flag=False

        #check if passwords match
        if postData['password'] != postData['c_password']:
            error.append("Passwords Do Not Match")
            flag=False

        if flag:
            print "User info is valid."
            #salting and hashing password
            salt = binascii.b2a_hex(os.urandom(15))
            hashed_pw = md5.new(salt + postData['password']).hexdigest()
            #adding new user to database
            new_user=User.objects.create(first_name=postData['first_name'], last_name=postData['last_name'], email=postData['email'], salt=salt, password=hashed_pw)


            return(True, new_user)

        else:
            print "User Info is Invalid."
            return (False, error)



    def login(self, postData):
        flag=True
        error = []
        if len(postData['email']) < 1:
            error.append("Email Cannot Be Blank")
            flag=False

        if len(postData['password']) < 1:
            error.append("Password Cannot Be Blank")
            flag=False

    #if email in database then compare hashed passwords
        if User.objects.filter(email=postData['email']):
            salt = User.objects.get(email=postData['email']).salt
            hashed_pw = md5.new(salt + postData['password']).hexdigest()
            # compare hashed passwords
            if User.objects.get(email=postData['email']).password != hashed_pw:
                error.append('Incorrect Password')
                flag=False

        if flag: #success
            return True


        else:
            error.append('Email Has Not Been Registered')
            # do fail suff
            return (False, error)

class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    salt = models.CharField(max_length=255, default="")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()


    def __str__(self):
        return str(self.id) + self.first_name + self.last_name + self.email + self.salt + self.password
