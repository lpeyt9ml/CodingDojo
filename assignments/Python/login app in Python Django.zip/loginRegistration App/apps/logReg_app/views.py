# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, HttpResponse, redirect
from .models import User, UserManager
from django.contrib import messages
import re
import sys
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
ALPHA_REGEX = re.compile(r'^[A-Za-z]+$')

def index(request):
    return render(request, 'logReg_app/index.html')

def login(request):
    result = User.objects.login(request.POST)

    if result == True:
        return redirect ('/success')
    else:
        for error in result[1]:
            messages.info(request,error)
        return redirect('/')



def register(request):

    result2 = User.objects.register(request.POST)

    context = {
    'all_users':User.objects.all(),
    'new_user' : result2
    }
    print result2[1]

    if result2[0]:
        return render(request, 'logReg_app/success.html', context)
    else:
        for error in result2[1]:
            messages.info(request,error)
        return redirect('/')

    #results=User.objects.register(request.POST)
    #if results[0]:
        #return redirect('/success')
    #:
        for error in results:
            messages.error(request, error)
        return redirect('/')

def success(request):
    return render(request, 'logReg_app/success.html')

def reset(request):
    return redirect('/')
