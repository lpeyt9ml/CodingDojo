from flask import Flask, render_template, request, redirect, session, flash, url_for
# import the Connector function
from mysqlconnection import MySQLConnector
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')

app = Flask(__name__)
app.secret_key = 'secretKey'
# connect and store connection in "mysql", pass mysql database name to function
mysql = MySQLConnector(app, 'emailval')

@app.route('/')
def index():
    return render_template("index.html") #render page to enter email

@app.route('/update', methods=['POST']) #to add email to database
def update():
    query = "SELECT email FROM users"   #define your query, select all emails in database
    email = mysql.query_db(query)
    errors = False #default if there are no errors set errors=False
    if len(request.form['email']) < 1: #if email length is less than 1  then it is blank then flash error message
        errors = True
        flash("Cannot Leave Email Blank.")
    elif not EMAIL_REGEX.match(request.form['email']): #see if email in right format
        errors = True
        flash("Invalid Email. Please try again.")
    elif {'email' : request.form['email']} in email:
        errors = True
        flash("This Email Already Exists.")
    if errors: #if there are any errors return to index page
        return redirect('/')
    else:
        session['insert'] = 1
        query = "INSERT INTO users (email, created_at, updated_at) VALUES (:email, NOW(), NOW())"
        data = {'email': request.form['email']}
        mysql.query_db(query, data)
        return redirect('/success')


@app.route('/success')
def email_list():
    query = "SELECT * FROM users"                           # define your query
    emails = mysql.query_db(query)                           # run query with query_db()
    return render_template('results.html', email_list=emails, insert = session['insert']) # pass data to our template

@app.route('/remove', methods=['POST']) #to remove email from the databases
def remove():
    session['insert'] = 0
    errors = False
    if len(request.form['email']) < 1:
        errors = True
        flash("Please Do Not Leave Email Blank.")
    elif not EMAIL_REGEX.match(request.form['email']):
        errors = True
        flash("Invalid E-mail Address. Plese Try Again.")
    else:
        query = "SELECT email FROM users"     # define your query
        emails = mysql.query_db(query)
        if not {'email' : request.form['email']} in emails: #if email is not found in the database then cannot delete 
            errors = True
            flash("This Email Address Could Not Be Found.")
    if errors:
        return redirect('/success')
    else:
        query = "DELETE FROM users WHERE email = :email"
        data = {'email': request.form['email']}
        mysql.query_db(query, data)
        return redirect('/success')

if __name__ == "__main__":
    app.run(debug=True)
