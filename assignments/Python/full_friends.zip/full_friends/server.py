from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector

app = Flask(__name__)

mysql = MySQLConnector(app,'friendsdb')

@app.route('/')
def index():
    full_friends = mysql.query_db("SELECT CONCAT(first_name, ' ', last_name) as name, age, DATE_FORMAT(created_at, '%M %D %Y') as created_at FROM friends")
    print full_friends
    return render_template('index.html', full_friends = full_friends)

#add friend to database
@app.route('/friends', methods=['POST'])  #user input data from form inserted into database
def create():
    query = "INSERT INTO friends (first_name, last_name, age, created_at) VALUES (:first_name, :last_name, :age, NOW())"
    data = {
             'first_name': request.form['first_name'],
             'last_name': request.form['last_name'],
             'age': request.form['age']
           }

    # Run query, with dictionary values injected into the query.
    mysql.query_db(query, data)
    return redirect('/')


app.run(debug=True)
